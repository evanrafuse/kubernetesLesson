import React from 'react';
import './App.css';
import { BrowserRouter as Router } from 'react-router-dom';

function App() {
  return (
    <Router>
      <div className="App">
        <header className="App-header">
          <iframe width="560" height="315" src="https://www.youtube.com/embed/C-IvV8thrO4?autoplay=1&mute=1"></iframe>
          Oh hi World
        </header>
      </div>
    </Router>
  );
}

export default App;
