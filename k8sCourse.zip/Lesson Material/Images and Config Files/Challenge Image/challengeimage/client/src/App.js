import React from 'react';
import './App.css';
import { BrowserRouter as Router } from 'react-router-dom';

function App() {
  return (
    <Router>
      <div className="App">
        <header className="App-header">
          <a href='https://www.youtube.com/watch?v=-n9PtTErS6w'><button className='clusterButton'>Refresh Cluster</button></a>
          
        </header>
      </div>
    </Router>
  );
}

export default App;
